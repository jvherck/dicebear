`dicebear` is an API wrapper for https://dicebear.com. Using the API you can get custom avatars for your program.

* _Docs coming soon_